
tutao.tutanota.pay.Bootstrap.init();